package aplication.views;

import java.util.List;

import aplication.model.Edificio;
import aplication.model.Imagen;
import aplication.model.Persona;
import aplication.model.Unidad;

public class ReclamoView {

	private int numero;
	private PersonaView usuario;
	private EdificioView edificio;
	private String ubicacion;
	private String descripcion;
	private UnidadView unidad;
	private Estado estado;
	private List<ImagenView> imagenes;
	
	//Completar aplicando el patron dto
}
