package aplication.views;

public enum Estado {

	nuevo, abierto, enProceso, desestimado, anulado, terminado 
	
}
