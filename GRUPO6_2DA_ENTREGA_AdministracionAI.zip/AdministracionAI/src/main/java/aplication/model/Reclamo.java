package aplication.model;

import aplication.views.Estado;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name="reclamos")
public class Reclamo {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idReclamo;

    @Column(name = "documento", length = 20, nullable = false)
    private String documento;

    @Column(name = "codigo", nullable = false)
    private int codigo;

    @Column(name = "ubicacion", length = 300)
    private String ubicacion;

    @Column(name = "descripcion", length = 1000)
    private String descripcion;

    @Column(name = "identificador")
    private int identificador;

    @Column(name = "estado", length = 20, nullable = false)
    private String estado;

    // edifico reclamo
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "codigo", referencedColumnName = "codigo", insertable = false, updatable = false)
    private Edificio edificio;

    // persona reclamo
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "documento", referencedColumnName = "documento", insertable = false, updatable = false)
    private Persona persona;


    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "identificador", referencedColumnName = "identificador", insertable = false, updatable = false)
    private Unidad unidad;


    @OneToMany(mappedBy = "reclamo")
    @JsonIgnore
    private List<Imagen> imagenes;


    public Reclamo() {

    }

/*
*
* *
* * //no fata id reclamo ?
*
*
 */

    public Reclamo(Persona persona, Edificio edificio, String ubicacion, String descripcion, String estado, Unidad unidad){

    }

    public int getIdentificador() {
        return this.identificador;
    }

    public void agregarImagen(String direccion, String tipo) {
        //todo
    }

    public boolean cambiarEstado(String estado) {


        if(this.estado.equals("nuevo")  && (estado.equals("abierto")  ||estado.equals("desestimado") || estado.equals("anulado"))){
            this.estado = estado;
            System.out.println("ENTROO  A NUEVO- abierto");
            return true;
        }


        if(this.estado.equals("abierto")  && (estado.equals("en proceso")  ||estado.equals("desestimado") || estado.equals("anulado"))){
            this.estado = estado;
            return true;
        }

        if(this.estado.equals("en proceso")  && estado.equals("terminado")){
            this.estado = estado;
            return true;
        }

        if(this.estado.equals("en proceso")  && estado.equals("anulado")){
            this.estado = estado;
            return true;
        }

        return false;
     }

    public Edificio getEdificio() {
        return this.edificio;
    }
    public Persona getPersona() {
        return this.persona;
    }

    public Unidad getUnidad() {
        return this.unidad;
    }

    //<editor-fold desc="Getters">
    public String getDocumento() {
        return documento;
    }
    public int getCodigo(){
        return codigo;
    }
    public String getUbicacion(){
        return ubicacion;
    }
    public String getDescripcion(){
        return descripcion;
    }
    public String getEstado(){
        return estado;
    }

    //</editor-fold>

    //<editor-fold desc="Setters">
    public void setCodigo(int codigoEdificio){
        codigo = codigoEdificio;
    }
    public void setDocumento(String doc){
        documento = doc;
    }
    public void setDescripcion(String desc){
        descripcion = desc;
    }


    public void setUbicacion(String ubicacion){
        this.ubicacion = ubicacion;
    }
    public void setIdentificador(int id){
        identificador = id;
    }
    //</editor-fold>

}
