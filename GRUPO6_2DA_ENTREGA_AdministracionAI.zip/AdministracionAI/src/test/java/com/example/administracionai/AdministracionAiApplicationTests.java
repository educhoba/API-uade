package com.example.administracionai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdministracionAiApplicationTests {

    @Test
    void contextLoads() {
        System.out.println("funciona");
    }

}
